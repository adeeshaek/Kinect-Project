<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1346335995765" ID="ID_468304103" MODIFIED="1346336024236" TEXT="Extra funding applciation">
<node CREATED="1346336370617" ID="ID_122261588" MODIFIED="1346336372188" POSITION="right" TEXT="Proposal">
<node CREATED="1346336372846" ID="ID_1309475007" MODIFIED="1346336378611" TEXT="Scope of the project"/>
<node CREATED="1346336378972" ID="ID_775737769" MODIFIED="1346336383673" TEXT="Role that the student will play">
<node CREATED="1346336384060" ID="ID_745985674" MODIFIED="1346336387821" TEXT="Time commitment"/>
</node>
<node CREATED="1346336390833" ID="ID_1817765246" MODIFIED="1346336398685">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Nature of collab btw student
    </p>
    <p>
      and fac member
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1346336399409" ID="ID_264970685" MODIFIED="1346336415638">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Student's expectations on how
    </p>
    <p>
      working will improve his educ
    </p>
    <p>
      at IC
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1346336416632" ID="ID_1507103182" MODIFIED="1346336424618">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Why funds are needed and&#160;how
    </p>
    <p>
      they will be used
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</map>
