<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1344906249425" ID="ID_822292902" MODIFIED="1344906259457" TEXT="Report to Provost&apos;s offivce">
<node BACKGROUND_COLOR="#ccccff" CREATED="1344906260488" ID="ID_1006211274" MODIFIED="1344907795066" POSITION="right" TEXT="What I did">
<node CREATED="1344908127113" ID="ID_1162045953" MODIFIED="1344913196909" TEXT="Background">
<node CREATED="1344908147297" ID="ID_667356299" MODIFIED="1344908153204" TEXT="Independent Research">
<node CREATED="1344908153923" ID="ID_1272117191" MODIFIED="1344908157222" TEXT="With Dr. Stansfield"/>
<node CREATED="1344908157452" ID="ID_1244568661" MODIFIED="1344908169598">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Worked to find out if such a game<br />can be made using the Kinect
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1344908129709" ID="ID_986249355" MODIFIED="1344908200826" TEXT="Imagine Cup attempt">
<node CREATED="1344908178755" ID="ID_401227819" MODIFIED="1344908182631" TEXT="To create this game"/>
<node CREATED="1344908182901" ID="ID_367465617" MODIFIED="1344908187408" TEXT="Impossible using microsoft drivers"/>
<node CREATED="1344908188074" ID="ID_945931624" MODIFIED="1344908192754" TEXT="Kept going"/>
</node>
</node>
<node CREATED="1344907302509" ID="ID_358210063" MODIFIED="1344907363196">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Made a framework to make games<br />
    </p>
  </body>
</html></richcontent>
<node CREATED="1344907367730" ID="ID_1914391040" MODIFIED="1344907371652" TEXT="What it does">
<node CREATED="1344907345679" ID="ID_791588960" MODIFIED="1344907350120" TEXT="Helps people with motor issues"/>
<node CREATED="1344907395632" ID="ID_1753491529" MODIFIED="1344907397964" TEXT="Microsoft Kinect">
<node CREATED="1344907387893" ID="ID_1611324536" MODIFIED="1344907391442" TEXT="Using Unity3d"/>
<node CREATED="1344907393867" ID="ID_1678294927" MODIFIED="1344907395402" TEXT="Zigfu"/>
</node>
<node CREATED="1344907351214" ID="ID_1748455476" MODIFIED="1344907354781" TEXT="improve motor skills">
<node CREATED="1344907415746" ID="ID_1492781087" MODIFIED="1344907417882" TEXT="Thru exercise"/>
</node>
<node CREATED="1344907513460" ID="ID_1508523649" MODIFIED="1344907520469" TEXT="Supplement home exercise regimens">
<node CREATED="1344907524944" ID="ID_956477119" MODIFIED="1344907528016" TEXT="Which are expensive"/>
</node>
</node>
<node CREATED="1344907419160" ID="ID_1151389418" MODIFIED="1344907420292" TEXT="System">
<node CREATED="1344907421638" ID="ID_1879926808" MODIFIED="1344907437996" TEXT="Allows therapist to record exercises, send to patient"/>
<node CREATED="1344907438606" ID="ID_634281906" MODIFIED="1344907447675" TEXT="becomes part of a game in the patient&apos;s computer"/>
</node>
<node CREATED="1344907824592" ID="ID_413742966" MODIFIED="1344907843619" TEXT="What I have to show for it">
<node CREATED="1344907844275" ID="ID_303221313" MODIFIED="1344907847791" TEXT="Therapist&apos;s interface">
<node CREATED="1344907856882" ID="ID_1131057200" MODIFIED="1344907878568">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Intended for use by therapist to record exercises<br />so that he/she can transmit to patient
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1344907879169" ID="ID_323393346" MODIFIED="1344907900632">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Allows therapist to record the exercise
    </p>
    <p>
      Then mark key points in exercise
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1344907848020" ID="ID_784560992" MODIFIED="1344907850671" TEXT="Simple Game">
<node CREATED="1344907903031" ID="ID_1193580879" MODIFIED="1344907907950" TEXT="Simon Says">
<node CREATED="1344907909470" ID="ID_1276878878" MODIFIED="1344908004620" TEXT="Character model moves"/>
<node CREATED="1344908005177" ID="ID_879838414" MODIFIED="1344908017450" TEXT="player avatar has to follow"/>
<node CREATED="1344908017696" ID="ID_812684220" MODIFIED="1344908021404" TEXT="Limited time to move"/>
</node>
</node>
</node>
</node>
<node CREATED="1344907816622" ID="ID_1627194027" MODIFIED="1344907822374" TEXT="Made a simple game to test it"/>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1344906263178" ID="ID_858317252" MODIFIED="1344907795066" POSITION="right" TEXT="Problems I ran into ">
<node CREATED="1344906272225" ID="ID_1923965178" MODIFIED="1344906274524" TEXT="No GUI stuff">
<node CREATED="1344907547669" ID="ID_1303862818" MODIFIED="1344907559971" TEXT="Unity has weak GUI support"/>
<node CREATED="1344907562636" ID="ID_1947066706" MODIFIED="1344907569443" TEXT="3rd party GUIs were not suitable">
<node CREATED="1344907570030" ID="ID_192752477" MODIFIED="1344907571230" TEXT="Cost"/>
<node CREATED="1344907571437" ID="ID_1101402636" MODIFIED="1344907584400" TEXT="Graphics intensive"/>
</node>
</node>
<node CREATED="1344906275037" ID="ID_991317482" MODIFIED="1344906277823" TEXT="Undocumented">
<node CREATED="1344907589777" ID="ID_296547862" MODIFIED="1344907598836" TEXT="Zigfu has poor documentation"/>
</node>
<node CREATED="1344906279308" ID="ID_1093075625" MODIFIED="1344906286856" TEXT="No Gesture Engine">
<node CREATED="1344907600121" ID="ID_726541395" MODIFIED="1344907604442" TEXT="Does not come with gesture rec"/>
<node CREATED="1344907605332" ID="ID_1970158571" MODIFIED="1344907617432">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      No system that could be adpted&#160;to
    </p>
    <p>
      detect exercises
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1344906267114" ID="ID_2966399" MODIFIED="1344907795066" POSITION="right" TEXT="How I solved problems">
<node CREATED="1344906292325" ID="ID_1876630157" MODIFIED="1344906298039" TEXT="No GUI stuff">
<node CREATED="1344906306164" ID="ID_1415215529" MODIFIED="1344906307952" TEXT="Created my own"/>
</node>
<node CREATED="1344906298276" ID="ID_1716189961" MODIFIED="1344906300395" TEXT="Undocumented&apos;">
<node CREATED="1344906310072" ID="ID_1840116541" MODIFIED="1344906313804" TEXT="Found out what stuff did">
<node CREATED="1344907627423" ID="ID_1411225758" MODIFIED="1344907629905" TEXT="Reading the code"/>
</node>
<node CREATED="1344906320615" ID="ID_1115010828" MODIFIED="1344906322872" TEXT="Used forums">
<node CREATED="1344907638536" ID="ID_145698258" MODIFIED="1344907645778" TEXT="Interacted with other users facing problems">
<node CREATED="1344907646803" ID="ID_1888053546" MODIFIED="1344907648815" TEXT="Google groups"/>
<node CREATED="1344907649052" ID="ID_1394276421" MODIFIED="1344907655440" TEXT="Stackexchange; stackoverflow"/>
</node>
</node>
</node>
<node CREATED="1344906300642" ID="ID_1483960823" MODIFIED="1344906303355" TEXT="No gesture Engine">
<node CREATED="1344906314939" ID="ID_1037186163" MODIFIED="1344906319513" TEXT="Created my own">
<node CREATED="1344907666014" ID="ID_992223330" MODIFIED="1344907679185" TEXT="Based on information from Zigfu team member">
<node CREATED="1344907680060" ID="ID_431805074" MODIFIED="1344907682643" TEXT="Amir Hirsch"/>
</node>
<node CREATED="1344907687602" ID="ID_826861567" MODIFIED="1344907694451" TEXT="Basic principles">
<node CREATED="1344907695086" ID="ID_1394789076" MODIFIED="1344907705588" TEXT="detecting distance between equivalent joints"/>
</node>
</node>
<node CREATED="1344906323446" ID="ID_1177095220" MODIFIED="1344906325672" TEXT="Used forums"/>
</node>
</node>
<node CREATED="1344955191639" ID="ID_1634097074" MODIFIED="1344955195984" POSITION="right" TEXT="Advantages and limitations">
<node CREATED="1344908042480" ID="ID_1019628710" MODIFIED="1344908053351" TEXT="Limitations of my system">
<node CREATED="1344908054384" ID="ID_1542756210" MODIFIED="1344908084600" TEXT="Kinect tracking has jitter">
<node CREATED="1344908086386" ID="ID_1996422734" MODIFIED="1344908098213" TEXT="Better software in future will improve this"/>
</node>
<node CREATED="1344908103103" ID="ID_128747114" MODIFIED="1344908107618" TEXT="Game is too simple">
<node CREATED="1344908108249" ID="ID_460623604" MODIFIED="1344908114651" TEXT="Focus on creating a full game in future"/>
</node>
</node>
<node CREATED="1344907471450" ID="ID_957460733" MODIFIED="1344955190715" TEXT="Advantages">
<node CREATED="1344907457407" ID="ID_1253965244" MODIFIED="1344907460356" TEXT="Cheap Hardware">
<node CREATED="1344907461164" ID="ID_615701817" MODIFIED="1344907467871" TEXT="Kinect is $150"/>
</node>
<node CREATED="1344907479602" ID="ID_147054762" MODIFIED="1344907482702" TEXT="Better exercise">
<node CREATED="1344907484274" ID="ID_692638049" MODIFIED="1344907489837" TEXT="Monitored and trakced"/>
</node>
</node>
</node>
<node BACKGROUND_COLOR="#ccccff" CREATED="1344907716630" ID="ID_1561985685" MODIFIED="1344907795066" POSITION="right" TEXT="Future Applications">
<node CREATED="1344907720126" ID="ID_1853339093" MODIFIED="1344907725120" TEXT="Use framework to make a game">
<node CREATED="1344907725913" ID="ID_565177610" MODIFIED="1344907736638" TEXT="A fun way to exercise"/>
<node CREATED="1344907736860" ID="ID_293331682" MODIFIED="1344907738701" TEXT="Cost effective"/>
<node CREATED="1344907738939" ID="ID_1654215435" MODIFIED="1344907748662" TEXT="Allows doctors to track improvement"/>
</node>
</node>
</node>
</map>
