using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;
/// <summary>
/// Class is used to provide Kinect functionality to a gameObject through Zigfu library
/// This class is adapted from the ZigSkeleton class provided by Zigfu
/// The methods created by Zigfu have been left untouched, except for comments
/// all the comments are mine
/// 
/// Author: Zigfu, Adeesha Ekanayake
/// Date: June - August 2012
/// </summary>
public class ZigSkeleton : MonoBehaviour 
{
    /// <summary>
    /// Variable for head of avatar
    /// </summary>
    public Transform Head;
    /// <summary>
    /// Variable for neck of avatar
    /// </summary>
    public Transform Neck;
	public Transform Torso;
	public Transform Waist;

	public Transform LeftCollar;
	public Transform LeftShoulder;
	public Transform LeftElbow;
	public Transform LeftWrist;
	public Transform LeftHand;
	public Transform LeftFingertip;

	public Transform RightCollar;
	public Transform RightShoulder;
	public Transform RightElbow;
	public Transform RightWrist;
	public Transform RightHand;
	public Transform RightFingertip;

	public Transform LeftHip;
	public Transform LeftKnee;
	public Transform LeftAnkle;
	public Transform LeftFoot;

	public Transform RightHip;
	public Transform RightKnee;
	public Transform RightAnkle;
	public Transform RightFoot;
	public bool mirror = false;
	public bool UpdateJointPositions = false;
	public bool UpdateRootPosition = false;
	public bool UpdateOrientation = true;
	public bool RotateToPsiPose = false;
    public static bool resetPose = true; //flag to make avatar return to standard pose
	public float RotationDamping = 30.0f;
	public Vector3 Scale = new Vector3(0.001f,0.001f,0.001f); 
	
	public Vector3 PositionBias = Vector3.zero;
	
	private Transform[] transforms;
	private Quaternion[] initialRotations;
	private Vector3 rootPosition;
	
	ZigJointId mirrorJoint(ZigJointId joint)
	{
		switch (joint) {
			case ZigJointId.LeftCollar:
				return ZigJointId.RightCollar;
			case ZigJointId.LeftShoulder:
				return ZigJointId.RightShoulder;
			case ZigJointId.LeftElbow:
				return ZigJointId.RightElbow;
			case ZigJointId.LeftWrist:
				return ZigJointId.RightWrist;
			case ZigJointId.LeftHand:
				return ZigJointId.RightHand;
			case ZigJointId.LeftFingertip:
				return ZigJointId.RightFingertip;
			case ZigJointId.LeftHip:
				return ZigJointId.RightHip;
			case ZigJointId.LeftKnee:
				return ZigJointId.RightKnee;
			case ZigJointId.LeftAnkle:
				return ZigJointId.RightAnkle;
			case ZigJointId.LeftFoot:
				return ZigJointId.RightFoot;
			
			case ZigJointId.RightCollar:
				return ZigJointId.LeftCollar;
			case ZigJointId.RightShoulder:
				return ZigJointId.LeftShoulder;
			case ZigJointId.RightElbow:
				return ZigJointId.LeftElbow;
			case ZigJointId.RightWrist:
				return ZigJointId.LeftWrist;
			case ZigJointId.RightHand:
				return ZigJointId.LeftHand;
			case ZigJointId.RightFingertip:
				return ZigJointId.LeftFingertip;
			case ZigJointId.RightHip:
				return ZigJointId.LeftHip;
			case ZigJointId.RightKnee:
				return ZigJointId.LeftKnee;
			case ZigJointId.RightAnkle:
				return ZigJointId.LeftAnkle;
			case ZigJointId.RightFoot:
				return ZigJointId.LeftFoot;
			
			
			default:
				return joint;
		}
	}
	
    //custom global vars
    public bool isSnapShotting = false; //is taking snapshot ***OBSOLETE***
    public bool isRecording = false; //is recording video
    public bool tick = false; //is flagged true at a rate of 60fps
    public bool isPlaying = false; //is playing video
    private bool madeRecording = false; //flagged true if a recording was made
    public int currentFrame = 0; //ID of current frame
    public int maxFrames = 0; //maximum number of frames

    /*
     * Lists to keep in memory
     * -----------------------
     */
    public List<SerializeScript.SnapshotClass> recordList; //frames list for recording
    public List<SerializeScript.SnapshotClass> playList; //frames list for playback
    public List<SerializeScript.SnapshotClass> backupPlayList; //backup of frames list
    public List<SerializeScript.KeyPoint> keyPointsList; //key points list
    public List<SerializeScript.KeyPoint> backupKPList; //backup key points list
    public string lastBackup; //keeps track of which list was backed up last
		
	public void Awake()
	{
		int jointCount = Enum.GetNames(typeof(ZigJointId)).Length;
		
		transforms = new Transform[jointCount];
		initialRotations = new Quaternion[jointCount];
		
        transforms[(int)ZigJointId.Head] = Head;
        transforms[(int)ZigJointId.Neck] = Neck;
        transforms[(int)ZigJointId.Torso] = Torso;
        transforms[(int)ZigJointId.Waist] = Waist;
        transforms[(int)ZigJointId.LeftCollar] = LeftCollar;
        transforms[(int)ZigJointId.LeftShoulder] = LeftShoulder;
        transforms[(int)ZigJointId.LeftElbow] = LeftElbow;
        transforms[(int)ZigJointId.LeftWrist] = LeftWrist;
        transforms[(int)ZigJointId.LeftHand] = LeftHand;
        transforms[(int)ZigJointId.LeftFingertip] = LeftFingertip;
        transforms[(int)ZigJointId.RightCollar] = RightCollar;
        transforms[(int)ZigJointId.RightShoulder] = RightShoulder;
        transforms[(int)ZigJointId.RightElbow] = RightElbow;
        transforms[(int)ZigJointId.RightWrist] = RightWrist;
        transforms[(int)ZigJointId.RightHand] = RightHand;
        transforms[(int)ZigJointId.RightFingertip] = RightFingertip;
        transforms[(int)ZigJointId.LeftHip] = LeftHip;
        transforms[(int)ZigJointId.LeftKnee] = LeftKnee;
        transforms[(int)ZigJointId.LeftAnkle] = LeftAnkle;
        transforms[(int)ZigJointId.LeftFoot] = LeftFoot;
        transforms[(int)ZigJointId.RightHip] = RightHip;
        transforms[(int)ZigJointId.RightKnee] = RightKnee;
        transforms[(int)ZigJointId.RightAnkle] = RightAnkle;
        transforms[(int)ZigJointId.RightFoot] = RightFoot;
		
		
		
		// save all initial rotations
		// NOTE: Assumes skeleton model is in "T" pose since all rotations are relative to that pose
        foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId))) {
			if (transforms[(int)j])	{
				// we will store the relative rotation of each joint from the gameobject rotation
				// we need this since we will be setting the joint's rotation (not localRotation) but we 
				// still want the rotations to be relative to our game object
				initialRotations[(int)j] = Quaternion.Inverse(transform.rotation) * transforms[(int)j].rotation;
			}
		}
    }

    void Start() 
    {
		// start out in calibration pose
		if (RotateToPsiPose) {
			RotateToCalibrationPose();
		}
	}
	
	void UpdateRoot(Vector3 skelRoot)
	{
        // +Z is backwards in OpenNI coordinates, so reverse it
        rootPosition = Vector3.Scale(new Vector3(skelRoot.x, skelRoot.y, skelRoot.z), doMirror(Scale)) + PositionBias;
		if (UpdateRootPosition) {
			transform.localPosition = (transform.rotation * rootPosition);
		}
	}
	
    //understand this method!!!
	void UpdateRotation(ZigJointId joint, Quaternion orientation) //There are Quarts!!!
	{

		joint = mirror ? mirrorJoint(joint) : joint;
        // make sure something is hooked up to this joint
        if (!transforms[(int)joint]) {
            return;
        }

        if (UpdateOrientation) {
			Quaternion newRotation = transform.rotation * orientation * initialRotations[(int)joint];
			if (mirror)
			{
				newRotation.y = -newRotation.y;
				newRotation.z = -newRotation.z;	
			}
			transforms[(int)joint].rotation = Quaternion.Slerp(transforms[(int)joint].rotation, newRotation, Time.deltaTime * RotationDamping);
        }
	}
	Vector3 doMirror(Vector3 vec)   
    {
        return new Vector3(mirror ? -vec.x : vec.x, vec.y, vec.z);
    }


	void UpdatePosition(ZigJointId joint, Vector3 position)
	{
		joint = mirror ? mirrorJoint(joint) : joint;
		// make sure something is hooked up to this joint
		if (!transforms[(int)joint]) {
			return;
		}
		
		if (UpdateJointPositions) {
            Vector3 dest = Vector3.Scale(position, doMirror(Scale)) - rootPosition;
			transforms[(int)joint].localPosition = Vector3.Lerp(transforms[(int)joint].localPosition, dest, Time.deltaTime * RotationDamping);
		}
	}

	public void RotateToCalibrationPose()
	{
        foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId))) {
			if (null != transforms[(int)j])	{
				transforms[(int)j].rotation = transform.rotation * initialRotations[(int)j];
			}
		}
		
		// calibration pose is skeleton base pose ("T") with both elbows bent in 90 degrees
		if (null != RightElbow) {
            RightElbow.rotation = transform.rotation * Quaternion.Euler(0, -90, 90) * initialRotations[(int)ZigJointId.RightElbow];
		}
		if (null != LeftElbow) {
            LeftElbow.rotation = transform.rotation * Quaternion.Euler(0, 90, -90) * initialRotations[(int)ZigJointId.LeftElbow];
		}
	}

    #region List mutator functions
    /*
     * function SyncLists
     * purpose: Synchronises the Keypoints and the Playlist. 
     *  Using the Playlist as a base, refreshes the Keypoints list
     * input/output: none
     * properties modified: Keypoints list
     */
    public void SyncLists()
    {
        if (playList != null) //make sure playList is not null
        {
            keyPointsList = new List<SerializeScript.KeyPoint>(); //clear the keyPointsList

            for (int i = 0; i < playList.Count; i++) //iterate through frame list
            {
                if (playList[i].isKeyFrame) //if this frame is a key frame, create corresponding
                                            //keypoint in KP list
                {
                    //create the new KeyPoint
                    SerializeScript.KeyPoint newKeyPoint = new SerializeScript.KeyPoint();
                    newKeyPoint.frameID = i; //initialize KP

                    keyPointsList.Add(newKeyPoint); //add new KP to list

                }
            }

            /*
            //write out the KPs
            foreach (SerializeScript.KeyPoint keyPoint in keyPointsList)
            {
                Debug.Log("keyPoint " + keyPoint.frameID);
            }
             */
        }

        else
            Debug.Log("Error: playlist is NULL");
    }


    /*
 * function BackupKPList
 * purpose: makes the old kp list = new kp list, to make it possible
 * for user to undo an action
 * input/output: none
 * properties modified: oldKPList
 
     * public void BackupKPList()
    {
        backupKPList = new List<SerializeScript.KeyPoint>();
        backupKPList.AddRange(keyPointsList);
    }

  * function RestoreKPList
  * purpose: reverts the last change to the backup KP list
  * input/output: none
  * properties modified: keyPointsList
    public void RestoreKPList()
    {
        keyPointsList = new List<SerializeScript.KeyPoint>();
        keyPointsList.AddRange(backupKPList);
    }
    */

    /*
     * function BackupPlayList
     * purpose: makes the old frame list = new frame list, to make it possible
     * for user to undo an action
     * input/output: none
     * properties modified: backupPlayList
     */
    public void BackupPlayList()
    {
        if (playList != null)
        {
            backupPlayList = new List<SerializeScript.SnapshotClass>();
            backupPlayList.AddRange(playList);
        }
        else
            Debug.Log("Error: playlist null");
    }

    /*
     * function RestorePlayList
     * purpose: reverts the last change to the play list
     * input/output: none
     * properties modified: PlayList
     */
    public void RestorePlayList()
    {
        playList = new List<SerializeScript.SnapshotClass>();
        playList.AddRange(backupPlayList);
        SyncLists();
    
    }

    /*
     * function SetStartOfPlay
     * purpose: defines a new start point for the recording
     * input/output: none
     * properties modifed: PlayList, BackupPlayList
     */
    public void SetStartOfPlay()
    {
        BackupPlayList(); //make undo possible

        playList.RemoveRange(0, currentFrame); //remove all frames before current frame

        maxFrames = maxFrames - currentFrame; //redefine max Frames

        currentFrame = 0; //reset playback to beginning

        GameObject.Find("GUI").GetComponent<ButtonScript>().SnapProgressBar(0, maxFrames); //snap slider

    }

    /*
     * function SetEndOfPlay
     * purpose: defines a new end point for the recording
     * input/output: none
     * properties modified: Playlist, BackupPlayList
     */
    public void SetEndOfPlay()
    {
        BackupPlayList(); //make undo possible

        //remove all the frames after current frame
        playList.RemoveRange(currentFrame, playList.Count - currentFrame - 1);

        maxFrames = currentFrame; //redefine Max frames
    }

    /*
     * function NewKeyPoint
     * purpose: creates a new key point
     *  first the curent frame is defined as a key point, then the
     *  sync method is called to refresh the keyPoints list in memory
     * input/output: none
     * properties modified: Keypoints List, Playlist
     */
    public void NewKeyPoint()
    {
        if (playList != null) //make sure frame is not null
        {
            if (currentFrame < playList.Count)
            {
                BackupPlayList();//make undo possible

                playList[currentFrame].isKeyFrame = true; //current frame is now a KeyFrame

                SyncLists(); //kp list is now refreshed
            }

            else
                Debug.Log("Error, frame ID is out of bounds");
        }

        else
            Debug.Log("Error: playList is null");
    }

    /*
     * function DeleteKeyPoint
     * purpose: deletes the key point selected in the GUI list
     *  first the key point that is selected is made a 'not key point'
     *  next the sync method is called
     * input/output:
     *  input: the frame ID selected in the GUI
     * properties modified: Keypoints List, playList
     */
    public void DeleteKeyPoint(int targetFrameID)
    {
        BackupPlayList(); //make undo possible
        
        if (keyPointsList != null)
        {
            int targetFrame = keyPointsList[targetFrameID].frameID;//find the target keypoint's frame ID

            playList[targetFrame].isKeyFrame = false; //set flag to false
            SyncLists(); //sync lists
            Debug.Log("KP Deleted");
        }

        else
            Debug.Log("Error: There are no Key Points");
    }

    /*
     * function UndoChanges
     * purpose: un-does changes to the keyPointsList as well as to the 
     *  playList, by clearing the playList and keyPointsList and replacing
     *  their contents with a copy of the backup lists.
     * input/output: none
     * properties modified: backupList, keyPointsList
     */
    public void UndoChanges()
    {
        /*
        switch (lastBackup) //decide which list should be restored
        {
            case "playList":
                RestorePlayList();
                lastBackup = "null"; 
                break;

            case "keyPointsList":
                RestorePlayList();
                SyncLists();
                //RestoreKPList();
                lastBackup = "null";
                break;

            case "null":
                Debug.Log("No more backups");
                break;

            default:
                Debug.Log("Error: backupLists called with invalid listID");
                break;
        }
         */
        RestorePlayList();
        //SyncLists();
    }

    /* 
     * function SaveToFile
     * purpose: let user save recording to a file
     * input/output: 
     *  input: string fileName: name of destination file
     * properties modified: none
     */
    public void SaveToFile(string fileName)
    {
        Debug.Log("Save function called");
        SerializeScript.SaveToDisk(fileName, playList); //save to file
    }

    /*
     * function LoadFromFile
     * purpose: let user load a specified file 
     * input: fileName - file name of file
     * output: none
     * properties modified: playList
     */
    public void LoadFromFile(string fileName)
    {
        BackupPlayList(); //make undo possible
        Debug.Log("Load function called");
        playList = SerializeScript.deserializeFromDisk(fileName);

        currentFrame = 0; //set playback to 0

        SyncLists(); //load key points
    }

    #endregion
    /*
 * function CustomReturnToT
 * purpose: make the character model pose in the T position from the
  * initial position, which is a 'hands up' position
 * input/output: none
 * properties modified: joint rotations of character
 */
    public void CustomReturnToT()
    {
        //not really sure why the RotateToCalibrationPose code has special
        //code to move the arms up, but this snippet doesn't have any such

        foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId)))
        {
            if (null != transforms[(int)j])
            {
                transforms[(int)j].rotation = transform.rotation * initialRotations[(int)j];
            }
        }

    }

    /*
* function CountNumberOfJoints
* purpose: counts the number of joints in the character, which ZigFu records
* input/output: none
* properties modified: joint rotations of character
*/
    public void CountNumberOfJoints()
    {
        int i = 0; //counting variable

        foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId)))
        {
            if (null != transforms[(int)j])
            {
                i++;
            }
        }

        Debug.Log(i);
    }

    /*
* function captureJoints
* purpose: iterates through the joints and captures the joint rots of the char
* input/output: none
* properties modified: a text file... (XML)
*/
    /*
    public void CaptureJoints(ZigTrackedUser user)
    {
        //create snapshot class
        SerializeScript.SnapshotClass snapShot = new SerializeScript.SnapshotClass();

        foreach (ZigInputJoint joint in user.Skeleton)
        {
            if (joint.GoodRotation) UpdateRotation(joint.Id, joint.Rotation);
            if (joint.GoodRotation) //store the joint in the struc
            {
                snapShot.jointRotations[(int)joint.Id] = joint.Rotation; //store joint
            }
            Debug.Log("Joint " + (int)joint.Id + " done");
        }

        Debug.Log("All joints done");

        //save class
        SerializeScript.SaveTempFile(snapShot); //save temp file
        Debug.Log("Saved file!");

        isSnapShotting = false; //reset the flag to false
    }
    */
    /*
     * function RecordJoints
     * purpose: Record movement of avatar. 
     *  This is a callback function
     */
    public void RecordJoints(ZigTrackedUser user)
    {
        //take a snapshot
        //create snapshot class
        SerializeScript.SnapshotClass snapShot = new SerializeScript.SnapshotClass();

        foreach (ZigInputJoint joint in user.Skeleton)
        {
            if (joint.GoodRotation) UpdateRotation(joint.Id, joint.Rotation);
            if (joint.GoodRotation) //store the joint in the struc
            {
                snapShot.jointRotations[(int)joint.Id] = joint.Rotation; //store joint
            }
        }

        //if need be, init list
        if (recordList == null)
            recordList = new List<SerializeScript.SnapshotClass>();

        //add to list
        recordList.Add(snapShot);

        tick = false; //set tick to false
        
    }

    /*
     * function StopRecording
     * purpose: saves the recording of the avatar and clears it
     */
    public void StopRecording()
    {
        //save the snapshot list
        if (recordList != null)
        {
            SerializeScript.SaveTempList(recordList); //save the list
            recordList = null; //clear the list
            madeRecording = true; //set flag to true;
            Debug.Log("Recording Saved");
        }

        else //handle error
            Debug.Log("Error: Recording null");

        //switch off the flag
        isRecording = false;
    }
    
/* 
 * function SnapToKeyPoint
 * purpose: Makes the avatar assume the position of a key point
 * input/output: 
 *  input: KeyPointID - ID of key point to snap to (int)
 *  output: none
 * properties modified: currentFrame
 */
    public void SnapToKeyPoint(int keyPointID)
    {
        //find frame number
        int targetFrame = keyPointsList[keyPointID].frameID; //frame we need

        //from start, play frames till key point is reached
        currentFrame = 0; //reset current frame 

        while (currentFrame < targetFrame)
        {
            PlayFrame();
            currentFrame++; //increment currentFrame
        }

        GameObject.Find("GUI").GetComponent<ButtonScript>().SnapProgressBar(targetFrame, maxFrames);
    }

/*
* function returnToSnapshot
* purpose: retuns user to pose recorded in snapshot
* input/output: none
* properties modified: joint rotations of character
*/
    
    /*public void ReturnToSnapShot()
    {

        Debug.Log("Returning to snapshot...");

        //read from snapshot
        SerializeScript.SnapshotClass snapShot = SerializeScript.LoadTempFile(); //load XML
        Debug.Log("Loaded Snapshot succesfully");

        //make the character pose

        //I am using a for loop not for each. Problems?
        foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId)))
        {
            if (null != transforms[(int)j])
            {
                transforms[(int)j].rotation = transform.rotation * snapShot.jointRotations[(int)j];
            }
        }

        Debug.Log("Snapshot Played Succesfully");
    }
    */

/*
* function PlayRecording
* purpose: Plays the recorded joint movements
* input/output: none
* properties modified: 
 *  playList, isPlaying
*/
    public void PlayRecording()
    {
        //reset frame index
       // currentFrame = 0; move to stop button

        if (currentFrame >= maxFrames)
            currentFrame = 0; //reset the playback if it has reached end

        if (playList == null)
        {
            if (madeRecording == true)
            {
                Debug.Log("Firing");
                playList = SerializeScript.LoadTempList(); //load a temp list
                isPlaying = true;
                maxFrames = playList.Count - 1;
            }

            else
            {
                Debug.Log("Error, no recording present");
                GameObject.Find("GUI").GetComponent<ButtonScript>().playButtonStateChange();
            }

        }
        else
        {
            Debug.Log("Recording Loaded Succesfully");
            //set playing to true
            isPlaying = true;
            maxFrames = playList.Count - 1;
        }
      

        //stop tracking movement? Handled in ButtonScript
    }

 /*
* function StopPlaying
* purpose: Stops playing the recorded joint movments
* input/output: none
* properties modified: 
 *  playList, isPlaying
*/
    public void StopPlaying()
    {
        //clear recording list
        playList = null;

        //set playing to false
        isPlaying = false;

        Debug.Log("Playback Stopped");

        currentFrame = 0; //reset frame Index

        //set GUI
        GameObject.Find("GUI").GetComponent<ButtonScript>().progressBar.value = 0;
        GameObject.Find("GUI").GetComponent<ButtonScript>().playButton.playBtnText = "Play";

    }

    /*
* function PausePlaying
* purpose: Pauses playing the recorded joint movments
* input/output: none
* properties modified: 
*  playList, isPlaying
*/
    public void PausePlaying()
    {
        //clear recording list
        //playList = null; DO THIS ONLY WHEN STOPPED

        //set playing to false
        isPlaying = false;

        Debug.Log("Playback Stopped");

    }

    /*
    * function PlayFrame
    * purpose: Plays one frame of the recorded joint movements
    * input/output: none
    * properties modified: joint rotations of character
    */
    public void PlayFrame()
    {
        //make sure playList is valid
        if (playList != null && currentFrame < playList.Count -1 )
        {

            //load frame?
            SerializeScript.SnapshotClass currFrame = playList[currentFrame];

            //play frame
            foreach (ZigJointId j in Enum.GetValues(typeof(ZigJointId)))
            {
                if (null != transforms[(int)j])
                {
                    transforms[(int)j].rotation = transform.rotation * currFrame.jointRotations[(int)j];
                }
            }

            //advance the frame ID
            currentFrame++;

        }

        else
        {
            Debug.Log("Error: playList is NULL");
            isPlaying = false; //stop playback
        }

    }

	public void SetRootPositionBias()
	{
		this.PositionBias = -rootPosition;
	}
	
	public void SetRootPositionBias(Vector3 bias)
	{
		this.PositionBias = bias;	
	}
	
    //core update function
	void Zig_UpdateUser(ZigTrackedUser user)
	{
		UpdateRoot(user.Position);
		if (user.SkeletonTracked) {
			foreach (ZigInputJoint joint in user.Skeleton) {
				if (joint.GoodPosition) UpdatePosition(joint.Id, joint.Position); //update positions
				if (joint.GoodRotation) UpdateRotation(joint.Id, joint.Rotation);   
			}
            
            //code to take a snapshot 
            //if (isSnapShotting) CaptureJoints(user); //call CaptureJoints

            //code to record
            if (isRecording && tick) RecordJoints(user);

		}
	}

}
