using UnityEngine;
using System.Collections;

/*
 * StaticDataScript
 * purpose: Keeps track of persistent data
 * 
 */

public class StaticDataScript : MonoBehaviour {

    /*
     * global vars
     */
    public static bool returnToCalibPose = false;

	// Use this for initialization
	void Start () {


	}
	
	// Update is called once per frame
	void Update () {
        if (returnToCalibPose)
        {
            Debug.Log("Hello");
            returnToCalibPose = false;
        }
	}
}
