/*
 * Intermediate Class
 * ------------------
 * purpose: To create an intermediate layer between
 * the GUI and the ZigSkeleton, which does all of the
 * intermediate processing
 */

using UnityEngine;
using System.Collections;

public class Intermediate : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
