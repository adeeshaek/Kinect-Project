/*
 * myGUITester
 * author: Adeesha Ekanayake
 * purpose: test out GUI components before using them
 */

using UnityEngine;
using System.Collections;
using System; //for eventArgs

public class myGUITester : MonoBehaviour {

    //list of default items
    public myGUIControls.SaveDialog myList;

    //event handler for click event
    public void ItemSelected(object sender, EventArgs e)
    {
        Debug.Log("Item " + myList.outputText + " selected!");
    }

    // Use for GUI initialization
    void OnGUI()
    {
        myList.Draw();
    }

	// Use this for initialization
	void Start () {
        /*
	    //initialize list for testing
        myList.add("Boo");
        myList.add("Hoo");
        myList.add("Bloody");
        myList.add("Hell");
        myList.add("Mate");
        myList.add("Cuckoo");
        myList.add("Clock");
        */
        //initialize list event handler
        myList.InitMethod();
        myList.saveButtonEventHandler += new myGUIControls.SaveButtonEventHandler(ItemSelected);
	}
	
	// Update is called once per frame
	void Update () {
	    //update functions of list
        myList.UpdateMethod();
	}
}
