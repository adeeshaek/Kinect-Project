using UnityEngine;
using System.Collections;
using System.Threading; //for timer class
using System.Collections.Generic; //for linked list
using System; //for EventArgs

public class ButtonScript : MonoBehaviour
{

    #region globalVars
    //global variables

    public static int NULLINT = 99999;


    #region flags
    private bool isRecording = false; //flags true when recording
    //above variable is duplicated in ZigSkeleton...
    #endregion

    /* 
     * Time related
     */
    float tickLength = 0.0166666666666667f; //tick length (set to 60fps)
    float elapsedTime = 0;

    #region GUIVariables
    //global variables for the GUI
    //recordButton
    [System.Serializable]
    public class RecordingButton
    {
        public float rectX, rectY, rectWidth, rectHeight; //the rectangle around rec btn
        public string rectText, recButtonText = "Not recording";
        public float sides = 10, top = 10;
    };
    public RecordingButton recordingButton;


    //playButton
    [System.Serializable]
    public class PlayButton
    {
        public float playBtnX, playBtnY, playBtnWidth, playBtnHeight; //dims of play btn
        public string playBtnText = "Play";
    };
    public PlayButton playButton;

    private bool isPlaying = false; //flags true when playing

    //progressBar
    [System.Serializable]
    public class ProgressBar
    {
        public float value, oldValue;
        public float X, Y, height, width;
    };
    public ProgressBar progressBar;

    //return to psi pose button
    [System.Serializable]
    public class ReturnButton
    {
        public float X, Y, height, width;
        public string text = "Return";
    };
    public ReturnButton returnButton;

    public myGUIControls.GUIList myList; //list of key points


    //capture still
    [System.Serializable]
    public class StillButton
    {
        public string buttonText = "Record Still";
        public float X, Y, height, width;
    };
    public StillButton stillButton;

    //tracking skeleton
    [System.Serializable]
    public class TrackingSkelButton
    {
        public bool isTracking = true;
        public string buttonText = "Tracking Skeleton";
        public float X, Y, height, width;
    };
    public TrackingSkelButton trackingSkelButton;

    //timer
    [System.Serializable]
    public class TimerText
    {
        public string text;
        public float X, Y, height, width;
    };
    public TimerText timerText;

    //edit Recording Buttons
    
    [System.Serializable]
    public class PanelButton
    {
        public string buttonText;
    };

    [System.Serializable]
    public class EditPanel
    {
        public string editPanelText = "Edit Panel";
        public float X, Y;
        public float buttonHeight, buttonWidth, buttonDistance;
        public PanelButton[] buttonPanel = new PanelButton[5];
        
    };
    public EditPanel editPanel;

    public myGUIControls.InputBox myInputBox;

    public myGUIControls.SaveDialog myLoadSaveDialog;

    /*
     * GUI Style info
     */
    //custom GUI style used to make the rectangle 
    //red when recording
    GUIStyle rectStyle = new GUIStyle();
    Color rectBackground = new Color(0, 0, 0);
    Color rectAltBackground = new Color(.8f, 0, 0);
    Color rectColor = new Color(0, 0, 0);

    //style to make the list work
    private GUIStyle listStyle = new GUIStyle();

    

    //create the drop-down list
    GUIContent[] keyPointsGUIList;

    //GUI specific initialization
    #endregion
    #endregion


    #region ButtonEventHandlers
    /*
     * function recordingButtonStateChange()
     * purpose: Change the state of the recording button
     *  so that is says 'recording' when recording and
     *  'not recording' when not recording
     * input/output: none
     * properties modified: isRecording, recButtonText
     */
    void recordingButtonStateChange() 
    {
        if (isRecording)
        {
            isRecording = false;
            recordingButton.recButtonText = "Not recording";
            rectColor = rectBackground;

            //change flag
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().isRecording = false;
            //save file
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().StopRecording();
        }
        else
        {
            isRecording = true;
            recordingButton.recButtonText = "Recording";
            rectColor = rectAltBackground;

            //change flag
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().isRecording = true;
            
            
        }
    }    
    
    /*
     * function playButtonStateChange()
     * purpose: Change the state of the play button
     *  so that is says 'pause' when playing and
     *  'play' when not playing
     * input/output: none
     * properties modified: isPlaying, playButtonText
     */
    public void playButtonStateChange()
    {
        if (isPlaying)
        {
            isPlaying = false;
            playButton.playBtnText = "Play";
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().PausePlaying();
        }
        else
        {
            isPlaying = true;
            playButton.playBtnText = "Paused";
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().PlayRecording();
        }
    }
    
    
 /*
 * function trackingSkelButtonStateChange()
 * purpose: Change the state of the trackingState button
 *  so that is says 'tracking' when tracking and 
  *  'not trakcing' when not tracking.
 * input/output: none
 * properties modified: isTracking, playButtonText
 */
    void trackingSkelButtonStateChange()
    {
        //make sure the text is appropriate
        if (trackingSkelButton.isTracking)
        {
            //change button's state
            trackingSkelButton.buttonText = "Not tracking";
            trackingSkelButton.isTracking = false;

            //change flags 
            GameObject.Find("ZigFu").GetComponent<ZigEngageSingleUser>().SkeletonTracked = false;
            /*
            /*
             * NOTE: Specific to single user skeletons
             * Change the code to make more general
             */
        }

        else
        {
            //change button state
            trackingSkelButton.buttonText = "Tracking";
            trackingSkelButton.isTracking = true;

            //change flags 
            GameObject.Find("ZigFu").GetComponent<ZigEngageSingleUser>().SkeletonTracked = true;
            /*
            /*
             * NOTE: Specific to single user skeletons
             * Change the code to make more general
             * 
             * ALSO: Make character return to T state now?
             */


        }

    }

    /*
     * function SetStartButtonEvent
     * purpose: event handler for Set Start
     *  sets a new start point for a frame
     *  recording
     * input / output: none
     * properties modified: playList
     */
    void SetStartButtonEvent()
    {
        
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().SetStartOfPlay();
    }

    /*
     * function SetEndButtonEvent
     * purpose: event handler for Set End
     *  sets a new end point for a frame
     *  recording
     * input / output: none
     * properties modified: playList
     */
    void SetEndButtonEvent()
    {

        GameObject.Find("Dana").GetComponent<ZigSkeleton>().SetEndOfPlay();
    }

    /*
     * function NewKeyPointButtonEvent
     * purpose: event handler for New Key Point
     *  adds a new key point to the KP list
     * input / output: none
     * properties modified: playList
     */
    void NewKeyPointButtonEvent()
    {
        
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().NewKeyPoint();

    }

    /*
     * function DeleteKeyPointButtonEvent
     * purpose: event handler for Delete Key Points
     *  deletes the selected / last recorded Key 
     *  Point
     * input / output: none
     * properties modified: playList
     */
    void DeleteKPButtonEvent()
    {
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().DeleteKeyPoint(myList.outputIndex);//call Handler
    }

    /*
     * function UndoButtonEvent
     * purpose: event handler for Undo Button
     *  Undoes changes made to keypoints list 
     *  as well as playlist
     * input / output: none
     * properties modified: playList
     */
    void UndoButtonEvent()
    {
        
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().RestorePlayList();

    }

    /*
     * function SaveButtonEvent
     * purpose: event handler for SaveButtonEvent
     *  saves the changes made in the keyPoints List
     *  as well as the playList
     * input / output: none
     * properties modified: playList
     */
    void SaveButtonEvent()
    {
        /*
        myInputBox.prompt("Save", "File name", "Ok", "Cancel",
            DialogBoxSaveClickHandler);
         */
        myLoadSaveDialog.Prompt("Save", "Cancel", myGUIControls.SaveDialog.eventType.Save);
    }

    /*
     * function LoadButtonEvent
     * purpose: event handler for LoadButtonEvent
     *  saves the changes made in the keyPoints List
     *  as well as the playList
     * input / output: none
     * properties modified: playList
     */
    void LoadButtonEvent()
    {

        myLoadSaveDialog.Prompt("Load", "Cancel", myGUIControls.SaveDialog.eventType.Load);
    }

    /*
     * function KeyPointsListEventHandler
     * purpose: event handler for myList
     *  makes the list work.
     * input / output: none
     * properties modified: playList
     */
    void KeyPointsListEventHandler(object sender, EventArgs e)
    {
        //snap to key point
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().SnapToKeyPoint(myList.outputIndex);
        Debug.Log("key point " + myList.outputIndex + " selected");
    }

    /*
     * function DialogBoxOkClickHandler
     * purpose: Event handler for the Ok Button in the dialog
     * box
     * input/output: none
     * properties modified: none
     */
    void DialogBoxOkClickHandler(object sender, myGUIControls.OkClickEventArgs args)
    {
        Debug.Log("OK clicked!");
    }

    /*
     * function DialogBoxSaveClickHandler
     * purpose: Handles event when user clicks save in save
     *  dialog box
     * input:
     *  object sender - name of sender
     *  args - arguments
     * output: none
     * properties modified: none
     */
    void DialogBoxSaveClickHandler(object sender, myGUIControls.OkClickEventArgs args)
    {
        //call save functiom
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().SaveToFile(myInputBox.textField.text);
    }

    /*
     * function LoadSaveDialogEventHandler
     * purpose: event handler for the Load/Save dialog
     *  loads or saves a file, depending on context
     * input: default input for event handler
     * output: none
     * properties modified: none
     */
    void LoadSaveDialogEventHandler(object sender, EventArgs args)
    {
        switch (myLoadSaveDialog.getCurrentEvent())
        {
            case myGUIControls.SaveDialog.eventType.Load:
                Debug.Log("Load event!");
                //call save function
                GameObject.Find("Dana").GetComponent<ZigSkeleton>()
                    .LoadFromFile(myLoadSaveDialog.outputText);
                break;

            case myGUIControls.SaveDialog.eventType.Save:
                Debug.Log("Save Event!");
                GameObject.Find("Dana").GetComponent<ZigSkeleton>()
                    .SaveToFile(myLoadSaveDialog.outputText);
                break;

        }
    }

    /*
 * function DialogBoxLoadClickHandler
 * purpose: Handles event when user clicks save in save
 *  dialog box
 * input:
 *  object sender - name of sender
 *  args - arguments
 * output: none
 * properties modified: none
 */
    void DialogBoxLoadClickHandler(object sender, myGUIControls.OkClickEventArgs args)
    {
        Debug.Log("Load button clicked");
        //call load function
        GameObject.Find("Dana").GetComponent<ZigSkeleton>().LoadFromFile(myInputBox.textField.text);
    }
    #endregion

    void OnGUI()
    {
        //define GUI style
        Texture2D rectTexture = new Texture2D(1, 1);
        rectTexture.SetPixel(0, 0, rectColor);

        rectTexture.Apply();

        rectStyle.normal.background = rectTexture;

        // keyPoints List
        myList.Draw();

        // background box
        GUI.Box(new Rect(recordingButton.rectX, recordingButton.rectY, recordingButton.rectWidth, recordingButton.rectHeight), recordingButton.rectText, rectStyle);

        //record button
        if (GUI.Button(new Rect(recordingButton.rectX + recordingButton.sides, recordingButton.rectY + recordingButton.top, recordingButton.rectWidth - (recordingButton.sides * 2),
            recordingButton.rectHeight - (recordingButton.top * 2)), recordingButton.recButtonText))
        {
            recordingButtonStateChange();
        }

        //play button
        if (GUI.Button(new Rect(playButton.playBtnX, playButton.playBtnY, playButton.playBtnWidth, playButton.playBtnHeight),
            playButton.playBtnText))
        {
            /* disabled for stills
                playButtonStateChange(); //change state of button 
            */

            //return to the still...
            //disable skel tracking
            GameObject.Find("ZigFu").GetComponent<ZigEngageSingleUser>().SkeletonTracked = false; //disable skeleton tracking
            trackingSkelButtonStateChange(); //set GUI state

            //call the method
            /* 
             * This code for stills
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().ReturnToSnapShot(); //custom code to return to T
             */

            playButtonStateChange();
        }

        //progress bar
        progressBar.value = GUI.HorizontalSlider(new Rect(progressBar.X, progressBar.Y, progressBar.width, progressBar.height),
            progressBar.value, 0.0f, 100f);

        //return button
        if (GUI.Button(new Rect(returnButton.X, returnButton.Y,
            returnButton.width, returnButton.height), returnButton.text))
        {
            
            GameObject.Find("ZigFu").GetComponent<ZigEngageSingleUser>().SkeletonTracked = false; //disable skeleton tracking
            trackingSkelButtonStateChange(); //change GUI state
            Debug.Log("Skeleton Tracking Disabled");

            /*
            for (int i = 0; i < 5; i++) //reset to calib pose. needs to be done a few times
                GameObject.Find("Dana").GetComponent<ZigSkeleton>().RotateToCalibrationPose(); //reset character pose
             */

            //GameObject.Find("Dana").GetComponent<ZigSkeleton>().ReturnToSnapShot(); //custom code to assume snapshot pose


        }

        //capture still button : NOW STOP BUTTON
        if (GUI.Button(new Rect(stillButton.X, stillButton.Y,
            stillButton.width, stillButton.height), stillButton.buttonText))
        {
            
            /*
             * Code to switch off script
            Debug.Log("Captured Still");
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().CountNumberOfJoints(); //count number of joints
             */
            //GameObject.Find("Dana").GetComponent<ZigSkeleton>().isSnapShotting = true;//capture joints.
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().StopPlaying();
        }

        //tracking skeleton button
        if (GUI.Button(new Rect(trackingSkelButton.X, trackingSkelButton.Y,
            trackingSkelButton.width, trackingSkelButton.height), trackingSkelButton.buttonText))
        {
            trackingSkelButtonStateChange();   
        }

        //timerText
        GUI.TextArea(new Rect(timerText.X, timerText.Y, timerText.width, timerText.height),
            timerText.text);

        //edit area
        GUI.Box(new Rect(editPanel.X, editPanel.Y, (editPanel.buttonPanel.Length) * (editPanel.buttonWidth + editPanel.buttonDistance) + editPanel.buttonDistance,
            editPanel.buttonHeight + (2 * editPanel.buttonDistance)), editPanel.editPanelText);

        //draw the edit panel buttons
        for (int i = 0; i < editPanel.buttonPanel.Length; i++)
        {
            if (GUI.Button(new Rect(editPanel.X + editPanel.buttonDistance +
                ((editPanel.buttonWidth + editPanel.buttonDistance) * i),
                editPanel.Y + editPanel.buttonDistance,
                editPanel.buttonWidth, editPanel.buttonHeight),
                editPanel.buttonPanel[i].buttonText))
            {
                //call event handlers for buttons in the panel
                switch (i)
                {
                    case 0:
                        SetStartButtonEvent();
                        break;

                    case 1:
                        SetEndButtonEvent();
                        break;

                    case 2:
                        NewKeyPointButtonEvent();
                        break;

                    case 3:
                        DeleteKPButtonEvent();
                        break;

                    case 4:
                        UndoButtonEvent();
                        break;

                    case 5:
                        SaveButtonEvent();
                        break;

                    case 6:
                        LoadButtonEvent();
                        break;
                }
            }
        }
        
        //create the dialogBox
        //make handler
        myLoadSaveDialog.Draw();
    }

    /*
     * function SnapProgressBar
     * purpose: Snaps progress bar to predeterined position
     * input: frameID - ID of frame to snap to
     *  maxFrames - max number of frames
     * output: none
     * properties modified: progressbar.value
     */
    public void SnapProgressBar(int frameID, int maxFrames)
    {
        progressBar.value = frameID * 100 / maxFrames;
    }

    /*
     * function timerTick
     * purpose: execute periodic function
     * input / output: none
     * properties modified:
     */
    public void timerTick()
    {
        if (isRecording)
        {
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().tick = true;
        }

        if (GameObject.Find("Dana").GetComponent<ZigSkeleton>().isPlaying)
        {
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().PlayFrame();

            progressBar.value = (GameObject.Find("Dana").GetComponent<ZigSkeleton>().currentFrame * 100 /
                GameObject.Find("Dana").GetComponent<ZigSkeleton>().maxFrames); //make progressbar work

            progressBar.oldValue = progressBar.value;

        }

        //make the progressbar work
        else
        {
            //check if value changed
            if (progressBar.oldValue != progressBar.value)
            {
                //Debug.Log("Value Changed");
                progressBar.oldValue = progressBar.value; //reset flags

                //change the frame played
                GameObject.Find("Dana").GetComponent<ZigSkeleton>().currentFrame
                    = (int)(progressBar.value *
                    GameObject.Find("Dana").GetComponent<ZigSkeleton>().maxFrames / 100);

                //make the figure assume the frame
                GameObject.Find("Dana").GetComponent<ZigSkeleton>().PlayFrame();

            }
        }

          
        
    }

    /*
     * UpdateKeyPointsList
     * purpose: Keeps the GUI list synced with the key points list
     * input / output: none
     * properties modified: keyPointsGUIList
     */
    void UpdateKeyPointsList()
    {
        //get data from the ZigSkeleton.cs
        List<SerializeScript.KeyPoint> keyPointData =
            GameObject.Find("Dana").GetComponent<ZigSkeleton>().keyPointsList;

        if (keyPointData != null)
        {
            //if keyPointData is not null, clear list each update
            myList.clear();

            if (keyPointData.Count > 0)
            {

                /* NEW STUFF
                 */

                for (int i = 0; i < keyPointData.Count; i++)
                {
                    string keyPointText = "Key Point " + i + ", Frame " + keyPointData[i].frameID;
                    myList.add(keyPointText); //add a new item to the list
                }

            }


            else //case if keyPointData is not null, but has 0 elements
            {

                myList.selectedButton.text = "No key Points";
            }
        }
        
        else //case if keyPointData == null
        {

            myList.selectedButton.text = "No key Points";
        }

        
    }

   
	// Use this for initialization
	void Start () {

        /*
         * Initialize GUI stuff
         */
        //add input box event handler
         myInputBox.OkClick += new myGUIControls.OkClickEventHandler(DialogBoxOkClickHandler);

        //for load/save box
         myLoadSaveDialog.InitMethod(); //init
         myLoadSaveDialog.saveButtonEventHandler +=
             new myGUIControls.SaveButtonEventHandler(LoadSaveDialogEventHandler);

        //add save button event handler
         myList.listItemSelectedEventHandler += new myGUIControls.GUIListItemSelectedEventHandler(KeyPointsListEventHandler);
         myList.InitMethod();//initialize list


	}
	
	// Update is called once per frame
	void Update () {
        UpdateKeyPointsList(); //call the key points update button
        myList.UpdateMethod();//update list
        myLoadSaveDialog.UpdateMethod(); //update files in directory
	}

    void FixedUpdate()
    {
        //make the timer Tick 50 times a second
        timerTick();

    }



}
