/* 
 * Class DataStructures
 * Purpose: Defines Data Structures for storing position/rotation data
 */

using UnityEngine;
using System.Collections;

public class DataStructures : MonoBehaviour {



	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
